<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_portfolio_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-portfolio';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Portfolio', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return ' eicon-folder-o';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_trainer',
			[
				'label' => esc_html__( 'Fitness Trainer', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<div class="row mt-60">
                  <div class="col-lg-12">
                     <div class="portfolio-menu text-center filter-button-group mb-40">
                        <button class="active" data-filter="*">All</button>
						<?php 
				 			 $args = array(
							 'taxonomy' => 'portfolio_category',
						  );
						  $portfolio_categorys = get_categories($args);
				 		 foreach( $portfolio_categorys as  $portfolio_categorys){
			 			  ?>
                        <button data-filter=".<?php echo  $portfolio_categorys->slug; ?>" class=""><?php echo  $portfolio_categorys->name; ?></button>
						<?php } ?>
                     </div>
                  </div>
               </div>
               <div class="row grid">

                  <?php 

				$portfolios = array(
					'post_type' => 'our_portfolio',
				);
				$portfolio_query = new WP_Query($portfolios);
				while($portfolio_query->have_posts()): $portfolio_query->the_post();
				?>
                  <div class="col-lg-6 <?php
					$get_cats = get_the_terms(get_the_ID(),'portfolio_category');
					foreach($get_cats as $get_cat){
					echo $get_cat->slug.' ' ;
					}
					?>">
                     <div class="single_portfolio_item mb-30">
                        <div class="portfolio_image">
                           <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url();?>" alt=""></a>
                        </div>
                        <div class="portfolio-info">
                           <div class="portfolio-content">
                              <span><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
                              <p>Weight loss Program</p>
                           </div>
                           <div class="portfolio_d-icon">
                              <a href="<?php the_permalink(); ?>" class="tp-btn-circle"><i class="fal fa-chevron-double-right"></i></a>
                           </div>
                        </div>
                     </div>
                  </div>
				<?php endwhile;?>

               </div>
         
<?php
	}

}
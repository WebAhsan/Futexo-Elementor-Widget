<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_counter_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-counter';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Counter', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'feature_counter',
			[
				'label' => esc_html__( 'Futexo Counter', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
			);
			$this->add_control(
				'counter_number',
				[
					'label' => esc_html__( 'Counter Number', 'futexo' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'default' => esc_html__( '93', 'futexo' ),
					'separator' => 'before',
					'label_block' => false,
					'placeholder' => esc_html__( '93', 'futexo' ),
				]
			);
			$this->add_control(
				'counter_title',
				[
					'label' => esc_html__( 'Counter Title', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Expert Trainer', 'futexo' ),
					'separator' => 'after',
					'label_block' => true,
					'placeholder' => esc_html__( 'Expert Trainer', 'futexo' ),
				]
			);
			$this->add_control(
				'counter_icon',
				[
					'label' => esc_html__( 'Counter Icon', 'futexo' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'separator' => 'after',
					'label_block' => true,
					'default' => [
						'value' => 'fal fa-clock',
						'library' => 'solid',
					],
				]
			);
			$this->add_control(
				'counter_shape_select',
				[
					'label' => esc_html__( 'Shape Image', 'futexo' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'futexo' ),
					'label_off' => esc_html__( 'Hide', 'futexo' ),
					'return_value' => 'yes',
					'default' => 'no',
				]
				);
	
			$this->add_control(
				'counter_shape',
				[
					'label' => esc_html__( 'Shape', 'futexo' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'separator' => 'after',
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src('/assets/img/about/about-shape.png'),
					],
				]
			);
	
			
			$this->end_controls_section();

			$this->start_controls_section(
				'feature_counter_style',
				[
					'label' => esc_html__( 'Counter Style', 'futexo' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'cunter_border',
						'label' => esc_html__( 'Box Border', 'futexo' ),
						'selector' => '{{WRAPPER}} .counter-item-border',
					]
				);
				$this->add_control(
					'counter_text_color',
					[
						'label' => esc_html__( 'Counter Text Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .counterinfo span' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'counter_title_typography',
						'selector' => '{{WRAPPER}} .counterinfo span',
						'separator' => 'after',
					]
				);
				$this->add_control(
					'counter_number_color',
					[
						'label' => esc_html__( 'Counter Number Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .counter-number h4' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'counter_number_typography',
						'selector' => '{{WRAPPER}} .counter-number h4',
						'separator' => 'after',
					]
				);
				$this->add_control(
					'counter_icon_color',
					[
						'label' => esc_html__( 'Counter Icon Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .counterinfo i' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'counter_icon_typography',
						'selector' => '{{WRAPPER}} .counterinfo i',
						'separator' => 'after',
					]
				);

	}
	
		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$counter_title = $settings['counter_title'];
		$counter_number = $settings['counter_number'];
		$counter_shape_select = $settings['counter_shape_select'];
		$counter_icon = $settings['counter_icon']['value'];
		$counter_shape = $settings['counter_shape']['url'];
		$cunter_border = $settings['cunter_border'];
		
		
		?>

<script>
		jQuery(function(){
			jQuery('.counter').counterUp({
		delay: 10,
		time: 1000
	});



		});

	</script>
<div class="counter-item counter-item-border">
                                 <div class="counter-number">
									 
                                    <h4><span class="counter"><?php  echo $counter_number;?></span></h4>
                                 </div>
                                 <div class="counterinfo">
                                    <i class="<?php  echo $counter_icon;?>"></i>
                                    <span><?php  echo $counter_title;?></span>
                                 </div>
								 <?php if($counter_shape_select == 'yes'){ ?>
                                 <div class="counter-shape">
                                    <img src="<?php echo $counter_shape; ?>" alt="">
                                 </div>

								 <?php }?>
   </div>
<?php
	}

}
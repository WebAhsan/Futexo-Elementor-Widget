<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_brand_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-brand';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Brand', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-logo';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_trainer',
			[
				'label' => esc_html__( 'Fitness Trainer', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'brand_img',
			[
				'label' => esc_html__( 'Brand Image', 'futexo' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'brand_title',
			[
				'label' => esc_html__( 'Brand Image', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				
			]
		);
		$this->add_control(
			'brand_list',
			[
				'label' => esc_html__( 'Brand List', 'futexo' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'brand_title' => esc_html__( 'Brand Image', 'futexo' ),
						'brand_img' => esc_html__( 'Brand Image', 'futexo' ),
					],
			
				],
				'title_field' => '{{{ brand_title }}}',
			]
		);

		$this->add_control(
			'brand_show',
			[
				'label' => esc_html__( 'Brand Shows', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'separator' => 'before',
				'options' => [
					'2'  => esc_html__( '2', 'futexo' ),
					'3'  => esc_html__( '3', 'futexo' ),
					'4'  => esc_html__( '4', 'futexo' ),
					'6'  => esc_html__( '6', 'futexo' ),
				],
			]
		);
		

		$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$brand_lists = $settings['brand_list'];
		$brand_show = $settings['brand_show'];
		
		?>

	<script>
	


 jQuery(function(){

	if (jQuery(".sponsor_slider-active").length > 0) {
		let testimonialTwo = new Swiper('.sponsor_slider-active', {
			slidesPerView: <?php echo $brand_show; ?>,
			spaceBetween: 30,
			// direction: 'vertical',
			loop: true,
			autoplay: {
				delay: 6000,
			},

			// If we need pagination
			pagination: {
				el: '.swiper-pagination',
				clickable: false,
			},
			// Navigation arrows

			// And if we need scrollbar
			scrollbar: {
				el: '.swiper-scrollbar',
			},

		});
	}


 });

	</script>


<div class="swiper-container sponsor_slider-active">
              <div class="swiper-wrapper">

			  	<?php  
					foreach($brand_lists as $brand_list){
						$brand_img = $brand_list['brand_img'];
					 ?>
                     <div class="swiper-slide sponsor_item">
                        <a href="#"><img src="<?php echo $brand_img['url']; ?>" alt=""></a>
                     </div>
						<?php }?>

                  </div>
               </div>


<?php
	}

}
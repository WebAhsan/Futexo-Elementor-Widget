<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_trainer_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-trainer';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Trainer', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-person';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_trainer',
			[
				'label' => esc_html__( 'Fitness Trainer', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'trainer_style',
			[
				'label' => esc_html__( 'Trainer Style', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-3',
				'options' => [
					'style-1'  => esc_html__( ' Style 1', 'futexo' ),
					'style-2'  => esc_html__( '	Style 2', 'futexo' ),
					'style-3'  => esc_html__( ' Style 3', 'futexo' ),

				],
			]
		);
		$this->add_control(
			'trainer_show',
			[
				'label' => esc_html__( 'Trainer Show', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'3'  => esc_html__( '3', 'futexo' ),
					'6'  => esc_html__( '6', 'futexo' ),
					'9'  => esc_html__( '9', 'futexo' ),
					'-1'  => esc_html__( '-1', 'futexo' ),

				],
			]
		);
		$this->add_control(
			'show_socail',
			[
				'label' => esc_html__( 'Show Social', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'futexo' ),
				'label_off' => esc_html__( 'Hide', 'futexo' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Trainer Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Icon Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'futexo' ),
				'selector' => '{{WRAPPER}} .trainer-soicial-icon a',
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);
		$this->add_control(
			'icon_color_hover',
			[
				'label' => esc_html__( 'Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_bg_color_hover',
			[
				'label' => esc_html__( 'Icon Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_hover',
				'label' => esc_html__( 'Border', 'futexo' ),
				'selector' => '{{WRAPPER}} .trainer-soicial-icon a:hover',
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'con_section',
			[
				'label' => esc_html__( 'Trainer Content', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .trainer-name',
			]
		);
		$this->add_control(
			'dignation_color',
			[
				'label' => esc_html__( 'Dignation Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' =>  'before',
				'selectors' => [
					'{{WRAPPER}} trainer-info p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'dignation_typography',
				'selector' => '{{WRAPPER}} trainer-info p',
			]
		);
	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$trainer_style = $settings['trainer_style'];
		$show_socail = $settings['show_socail'];
		$trainer_show = $settings['trainer_show'];
		

		if($trainer_style == 'style-1'){
			$trainer_style_class = 'col-xxl-3 col-lg-3 col-md-6';
		}
		elseif($trainer_style == 'style-2'){
			$trainer_style_class = 'col-xxl-4 col-lg-4 col-md-4';
		}
		elseif($trainer_style == 'style-3'){
			$trainer_style_class = 'col-xxl-6 col-lg-6 col-md-12';
		}
		?>

<div class="row mt-35">
                  
				  <?php 
				  
					 $args = array(
						'post_type' => 'fitness_trainer',
						'posts_per_page' => $trainer_show,
					 );
   
					 $trainer_query = new WP_Query($args);
					 while($trainer_query->have_posts()):$trainer_query->the_post();
				  
				  ?>
   
					 <div class="<?php echo $trainer_style_class; ?>">
					 <div class="trainer-single wow fadeInUp mb-30" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
						   <div class="trainer-image">
							  <a href="team-details.html"><?php the_post_thumbnail(); ?></a>
						   </div>
						   <div class="trainer-info">
							  <h5 class="trainer-name"><a href="<?php the_permalink();?>"><?php the_title();?></a></h5>
							  <p class="mb-20"><?php the_field('trainer_dignation'); ?></p>
							  <?php if(	$show_socail == 'yes'):?>
							  <div class="trainer-soicial-icon">
							  <?php
							  $trainer_socials = get_field('trainer_social');
							  if($trainer_socials ){
							  foreach($trainer_socials as $trainer_social){
							  ?>
								 <a href="<?php echo $trainer_social['social_url'];  ?>"><?php echo $trainer_social['social_icon'];  ?></a>
							  
								 <?php }} ?>
							  </div>

								<?php endif;?>

						   </div>
						   <div class="trainer-btn">
							  <a href="team-details.html" class="tp-btn-square"><i class="fal fa-chevron-double-right"></i></a>
						   </div>
						</div>
					  
					 </div>
   
					
   
					 <?php endwhile;?>
   
				  </div>



<?php
	}

}
<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_schedule_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-schedule';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Schedule', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return ' eicon-time-line';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'schedule_sunday_list',
			[
				'label' => esc_html__( 'Fitness List', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'fitness_day', [
				'label' => esc_html__( 'Fitness Day', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => esc_html__( 'sunday' , 'futexo' ),
				'label_block' => true,
				'options' => [
					'Sunday'  => esc_html__( 'sunday', 'futexo' ),
					'Monday'  => esc_html__( 'monday', 'futexo' ),
					'Tuesday'  => esc_html__( 'tuesday', 'futexo' ),
					'Wednesday'  => esc_html__( 'wednesday', 'futexo' ),
					'Thursday'  => esc_html__( 'thursday', 'futexo' ),
					'Friday'  => esc_html__( 'friday', 'futexo' ),
				],
			]
		);

		$repeater->add_control(
			'fitness_time', [
				'label' => esc_html__( 'Fitness Time', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '07:00 Am' , 'futexo' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'fitness_work', [
				'label' => esc_html__( 'Fitness Work', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Boxing' , 'futexo' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'fitness_trainer', [
				'label' => esc_html__( 'Fitness Trainer', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Alena Jopsep' , 'futexo' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Fitness List', 'futexo' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'fitness_day' => esc_html__( 'Sunday', 'futexo' ),
					],
				],
				'title_field' => '{{{ fitness_day }}}',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'schedule_time_list',
			[
				'label' => esc_html__( 'Time List', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);



		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'fitness_time', [
				'label' => esc_html__( 'Fitness Time', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '7:00 AM' , 'futexo' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'time_list',
			[
				'label' => esc_html__( 'Sunday List', 'futexo' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'fitness_time' => esc_html__( '7:00 AM', 'futexo' ),
					],
				],
				'title_field' => '{{{ fitness_time }}}',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		
		
		?>

<div class="futexo-classes-tab">
                                   <div class="tab-content current">
                                       <div class="futexo-tab-d futexo-tab-all">
                                          <span class="schedule-icon">
                                             <i class="flaticon-muscle"></i>
                                          </span>
                                          <ul>
                                             <li><span class="time">07:00 am</span></li>
                                             <li><span class="time">10:00 am</span></li>
                                             <li><span class="time">04:00 pm</span></li>
                                             <li><span class="time">06:00 pm</span></li>
                                             <li><span class="time">08:00 pm</span></li>
                                          </ul>
                                       </div>

                                       <div class="futexo-tab-all">
                                          <h5>sunday</h5>
                                          <ul>
                                              <li><span>Boxing</span>Alena Jopsep</li>
                                              <li><span>Cardio</span>Bull Mentor</li>
                                              <li><span>Yoga</span>Fiter Jamson</li>
                                              <li><span>Cardio</span>Bull Mentor</li>
                                              <li><span>Ultragym</span>Roser Mack</li>
                                          </ul>
                                       </div>

									   
                                   </div>
                               </div>
		



<?php
	}

}
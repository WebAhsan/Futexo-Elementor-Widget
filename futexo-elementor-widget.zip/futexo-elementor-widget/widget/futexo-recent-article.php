<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_article_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-recent-article';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Recent Article', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_testimonial',
			[
				'label' => esc_html__( 'Fuutexo Testimonial', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'testimonial_des', [
				'label' => esc_html__( 'Testimonail', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'List Title' , 'futexo' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'client_name', [
				'label' => esc_html__( 'Client Name', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Calwen Synton' , 'futexo' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'client_degination', [
				'label' => esc_html__( 'Client Degination', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Sr Designer' , 'futexo' ),
				'label_block' => true,
			]
		);



		$this->add_control(
			'tesitmonial',
			[
				'label' => esc_html__( 'Repeater List', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'testimonial_des' => esc_html__( 'Title #1', 'futexo' ),
						'client_name' => esc_html__( 'Calwen Synton', 'futexo' ),
						'client_degination' => esc_html__( 'Sr Designer', 'futexo' ),
					],
				],
				'title_field' => '{{{ client_name }}}',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Trainer Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);

		$this->add_control(
			'des_color',
			[
				'label' => esc_html__( 'Description Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial_description' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'name_color',
			[
				'label' => esc_html__( 'Name Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .client-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'degination_color',
			[
				'label' => esc_html__( 'Degination Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .client-degination' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'futexo' ),
				'selector' => '{{WRAPPER}} .trainer-soicial-icon a',
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);
		$this->add_control(
			'icon_color_hover',
			[
				'label' => esc_html__( 'Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_bg_color_hover',
			[
				'label' => esc_html__( 'Icon Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_hover',
				'label' => esc_html__( 'Border', 'futexo' ),
				'selector' => '{{WRAPPER}} .trainer-soicial-icon a:hover',
			]
		);

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
	
		
		?>


					<div class="blog__slider-inner p-relative">
                     <div class="blog-slider_active swiper-container wow fadeInUp" data-wow-delay=".4s">
                        <div class="blog-slider_wrapper swiper-wrapper">

						<?php 

						$args = array(
							'post_type' => 'post',
							'posts_per_page' => 10,
						);
						$recent_article_query = new WP_Query($args);
						while($recent_article_query->have_posts()):$recent_article_query->the_post();
						?>

                           <div class="bolg_slider_item swiper-slide">
                              <div class="row g-0">
                                 <div class="col-lg-6">
                                    
									<div class="blog-image">
                                       <a href="<?php the_permalink();?>"><img src="<?php the_post_thumbnail_url(); ?>" class="img-fluid" alt="blog-img"></a>
                                    </div>
                                     
                                 </div>
                                 <div class="col-lg-6">
                                    <div class="blog_content mt-85" data-background="assets/img/blog/blog-bg.jpg">
                                       <div class="blog-info">
                                          <div class="blog__meta mb-15">
                                             <span><a href="<?php the_permalink(); ?>"><i class="far fa-bookmark"></i><?php the_category(' ');?></a></span>
                                             <span><a href="#"><i class="far fa-comments"></i><?php echo get_comments_number();?></a></span>
                                          </div>
                                          <h5 class="blog_title mb-20"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h5>
                                          <p class="mb-40"><?php echo substr(get_the_excerpt(), 250);?></p>
                                          <div class="blog-button">
                                             <a href="<?php the_permalink(); ?>" class="tp-btn-round">Read More <i class="fal fa-chevron-double-right"></i></a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>

						   <?php endwhile;?>

           
                        </div>
                     </div>
                     <!-- If we need navigation buttons -->
                     <div class="swiper-button-prev bs-button bs-button-prev"><i class="far fa-long-arrow-left"></i></div>
                     <div class="swiper-button-next bs-button bs-button-next"><i class="far fa-long-arrow-right"></i></div>
                  </div>

		 <?php
	}

}
<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_feature_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'feature';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Feature', 'elementor-futexo-widget' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return ' eicon-flash';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'feature_section',
			[
				'label' => esc_html__( 'Futexo Feature', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'feature_icon',
			[
				'label' => esc_html__( 'Social Icons', 'futexo' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'separator' => 'after',
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-star',
				],
			]
		);

		
		$repeater->add_control(
			'feature_title',
			[
				'label' => esc_html__( 'Add Title', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Dedicated Services', 'futexo' ),
				'placeholder' => esc_html__( 'Type your title here', 'futexo' ),
			]
		);
		$repeater->add_control(
			'active_feature',
			[
				'label' => esc_html__( 'Active Feature', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'futexo' ),
				'label_off' => esc_html__( 'No', 'futexo' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'feature_list',
			[
				'label' => esc_html__( 'Repeater List', 'futexo' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'feature_title' => esc_html__( 'Title #1', 'futexo' ),
						'feature_icon' => esc_html__( 'Item content. Click the edit button to change this text.', 'futexo' ),
					],
					[
						'feature_title' => esc_html__( 'Title #2', 'futexo' ),
						'feature_icon' => esc_html__( 'Item content. Click the edit button to change this text.', 'futexo' ),
					],
				],
				'title_field' => '{{{ feature_title }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'feature_style',
			[
				'label' => esc_html__( 'Styles', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
			
		);


		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);
		$this->add_control(
			'feature_title_line',
			[
				'label' => esc_html__( 'Feature Title Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,

			]
		);
		$this->add_control(
			'feature_title_clr',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-features-item span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_icon_color_title',
			[
				'label' => esc_html__( 'Feature Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				

			]
		);
		$this->add_control(
			'feature_icon_color',
			[
				'label' => esc_html__( 'Social Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tpfeatures-icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_icon_bg',
			[
				'label' => esc_html__( 'Social Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-features-item .tpfeatures-icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_box_bg_title',
			[
				'label' => esc_html__( 'Feature Box Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,

			]
		);
		$this->add_control(
			'feature_box_bg',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-features-item' => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);
		$this->add_control(
			'feature_title__hover_line',
			[
				'label' => esc_html__( 'Feature Title Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,

			]
		);
		$this->add_control(
			'feature_title_hover_clr',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-features-item:hover span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'feature_icon_color_hover_title',
			[
				'label' => esc_html__( 'Feature Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				

			]
		);
		$this->add_control(
			'feature_icon_hover_color',
			[
				'label' => esc_html__( 'Social Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-features-item:hover .tpfeatures-icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_icon_hover_bg',
			[
				'label' => esc_html__( 'Social Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-features-item:hover .tpfeatures-icon' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'feature_box_bg_hover_title',
			[
				'label' => esc_html__( 'Feature Box Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,

			]
		);
		$this->add_control(
			'feature_box_bg_hover',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-features-item:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_section();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .tp-features-item span',
			]
		);

	}

		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		$feature_title = $settings['feature_title'];
		$feature_icon = $settings['feature_icon'];
	
		
		?>

		<div class="tpfeatures-lists">
		<div class="container">
		   <div class="row g-0">

			<?php 
			
			$feature_lists = $settings['feature_list'];
			if($feature_lists){
				foreach($feature_lists as $feature_list){
				 $feature_icon = $feature_list['feature_icon'];
				 $feature_title = $feature_list['feature_title'];
				 $active_feature = $feature_list['active_feature'];
				 
			
			
			?>
			  <div class="col-lg-3 col-md-3">

			  <?php if($active_feature == 'yes'){?>
				 <div class="tp-features-item tp-features-item-border item-active text-center mb-30 wow fadeInUp"  data-wow-delay=".2s">
					<div class="tpfeatures-icon mb-25">
						
					   <i class="<?php echo $feature_icon["value"]; ?>"></i>
					</div>
					<span><?php echo $feature_title; ?></span>
				 </div>
			  </div>
			  <?php }else{ ?>
				<div class="tp-features-item tp-features-item-border text-center mb-30 wow fadeInUp"  data-wow-delay=".2s">
					<div class="tpfeatures-icon mb-25">
						
					   <i class="<?php echo $feature_icon["value"]; ?>"></i>
					</div>
					<span><?php echo $feature_title; ?></span>
				 </div>
			  </div>



			<?php }}}?>

		   </div>
		</div>
	 </div>

<?php

	}

}
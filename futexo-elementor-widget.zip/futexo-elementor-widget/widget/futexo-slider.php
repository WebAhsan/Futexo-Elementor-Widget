<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_slider_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futexo';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Slider', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return ' eicon-slider-video';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'slider_section',
			[
				'label' => esc_html__( 'Futexo Slider', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'slider_show_number',
			[
				'label' => esc_html__( 'Slider Shows', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'label_block' => true,
				'options' => [
					'1' => esc_html__( '1', 'futexo' ),
					'2'  => esc_html__( '2', 'futexo' ),
					'5' => esc_html__( '5', 'futexo' ),
				],
			]
		);
		$this->add_control(
			'slider_title_animation',
			[
				'label' => esc_html__( 'Slider Shows', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'fadeInUp',
				'separator' => 'before',
				'options' => [
					'bounce' => esc_html__( 'bounce', 'futexo' ),
					'flash' => esc_html__( 'flash', 'futexo' ),
					'pulse' => esc_html__( 'pulse', 'futexo' ),
					'shakeX' => esc_html__( 'shakeX', 'futexo' ),
					'headShake' => esc_html__( 'headShake', 'futexo' ),
					'swing' => esc_html__( 'swing', 'futexo' ),
					'tada' => esc_html__( 'tada', 'futexo' ),
					'wobble' => esc_html__( 'wobble', 'futexo' ),
					'jello' => esc_html__( 'jello', 'futexo' ),
					'heartBeat' => esc_html__( 'heartBeat', 'futexo' ),
					'backInDown' => esc_html__( 'backInDown', 'futexo' ),
					'backInLeft' => esc_html__( 'backInLeft', 'futexo' ),
					'backInRight' => esc_html__( 'backInRight', 'futexo' ),
					'backInUp' => esc_html__( 'backInUp', 'futexo' ),
					'backOutDown' => esc_html__( 'backOutDown', 'futexo' ),
					'backOutLeft' => esc_html__( 'backOutLeft', 'futexo' ),
					'backOutRight' => esc_html__( 'backOutRight', 'futexo' ),
					'backOutUp' => esc_html__( 'backOutUp', 'futexo' ),
					'bounceIn' => esc_html__( 'bounceIn', 'futexo' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'futexo' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'futexo' ),
					'bounceOut' => esc_html__( 'bounceOut', 'futexo' ),
					'bounceOutDown' => esc_html__( 'bounceOutDown', 'futexo' ),
					'bounceOutLeft' => esc_html__( 'bounceOutLeft', 'futexo' ),
					'bounceOutRight' => esc_html__( 'bounceOutRight', 'futexo' ),
					'bounceOutUp' => esc_html__( 'bounceOutUp', 'futexo' ),
					'fading_entrances' => esc_html__( 'fading_entrances', 'futexo' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'futexo' ),
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'futexo' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'futexo' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'futexo' ),
				],
			]
		);
		$this->add_control(
			'slider_title_animation_delay',
			[
				'label' => esc_html__( 'Animation Delay', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => .2,
				'separator' => 'after',
				'label_block' => true,
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'feature_style',
			[
				'label' => esc_html__( 'Styles', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);
		$this->add_control(
			'feature_slider_title_line',
			[
				'label' => esc_html__( 'Title Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'feature_slider_clr',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .hero-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_slider_line',
			[
				'label' => esc_html__( 'Subtitle Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'feature_slider_subtitle_clr',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .slider-all-text span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_slider_des',
			[
				'label' => esc_html__( 'Description Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'feature_slider_des_clr',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .slider-all-text .description' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_slider_btn_line',
			[
				'label' => esc_html__( 'Button', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'feature_slider_btn_bg',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_slider_btn_text',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);
		$this->add_control(
			'feature_slider_btn_line_hover',
			[
				'label' => esc_html__( 'Button', 'futexo' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_control(
			'feature_slider_btn_bg_hover',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tp-btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_slider_btn_text_hover',
			[
				'label' => esc_html__( 'Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .tp-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
	}
	
		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$slider_show_number = $settings['slider_show_number'];
		$slider_title_animation = $settings['slider_title_animation'];
		$slider_title_animation_delay = $settings['slider_title_animation_delay'];
		
		
		?>

<div class="hero-area fix">
            <div class="hero-slider slider__active swiper-container swiper-container-fade">
               <div class="swiper-wrapper p-relative">
                  <div class="hero-pagination"></div>

                <?php 
                
                $args = array(
                    'post_type' => 'futexo_slider',
                    'posts_per_page' => $slider_show_number,
                );

				

                $query = new WP_Query($args);
                while( $query->have_posts()):$query->the_post();
                
                $slider_subtitle = get_post_meta( get_the_ID(), 'futexo_slider_subtitle', true );
                $slider_btn_text = get_post_meta( get_the_ID(), 'futexo_slider_btn_text',true );
                $slider_btn_link = get_post_meta( get_the_ID(), 'futexo_slider_btn_link',true );
                $futexo_slider_video_link = get_post_meta( get_the_ID(), 'futexo_slider_video_link',true );
                ?>

                  <div class="item-slider swiper-slide">
                     <div class="slide-bg" data-background="<?php the_post_thumbnail_url(); ?>"></div>
                     <div class="container">
                        <div class="row ">
                           <div class="col-lg-12">
                              <div class="slider-all-text">
                                 <span data-animation="<?php echo $slider_title_animation;?>" data-delay="<?php echo $slider_title_animation_delay;?>s"><?php echo esc_html($slider_subtitle); ?></span>
                                 <h2 class="hero-title" data-animation="fadeInUp" data-delay=".4s"><?php the_title();?></h2>
                                 <p class="description mt-10 mb-50" data-animation="fadeInUp" data-delay=".6s">Hardest part is walking out in the front door</p>
                                 <div class="play-option" data-animation="fadeInUp" data-delay=".8s">
                                 <?php if($slider_btn_text){ ?>
                                    <a href="<?php echo esc_url($slider_btn_link); ?>" class="tp-btn"><?php echo esc_html($slider_btn_text);  ?> <i class="fal fa-chevron-double-right"></i></a>
                                    <?php } ?>
                                    <?php if($futexo_slider_video_link){ ?>
                                       <a class="video-play-button hero-play popup-video ml-30" href="<?php  echo esc_url( $futexo_slider_video_link); ?>">
                                          <i class="fas fa-play"></i>
                                       </a>
                                    <?php } ?>
                                 </div>
                              </div>
                              <div class="hero-social-icon">
                                 <?php
                                 
                                 $slider_icon_boxs = get_field( "slider_icon_box" ); 
								 if($slider_icon_boxs){
                                 foreach($slider_icon_boxs as $slider_icon_box){
                                    $slider_icon_link = $slider_icon_box['slider_icon_link'];
                                    $slider_icon = $slider_icon_box['slider_icon'];
                                    
                                 ?>
                                 <a href="<?php echo esc_url($slider_icon_link['url']);?>"><i class="<?php echo esc_html($slider_icon);?>"></i></a>
                                 <?php  }} ?>

                              </div>
                           </div>
                     </div>
                     </div>
                  </div>

                <?php endwhile; ?>
               </div>
            </div>
         </div>

<?php
	}

}
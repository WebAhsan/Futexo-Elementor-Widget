<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_heading_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futexoheading';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Heading', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-heading';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'feature_headinng',
			[
				'label' => esc_html__( 'Futexo Heading', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
			);
			$this->add_control(
				'heading_icon',
				[
					'label' => esc_html__( 'Heading Border Icons', 'futexo' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'separator' => 'after',
					'fa4compatibility' => 'icon',
					'default' => [
						'value' => 'far fa-circle',
					],
				]
			);
			$this->add_control(
				'heading_border_color',
				[
					'label' => esc_html__( 'Border Color', 'futexo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tpsub-title-two::before,.tpsub-title-two::after' => 'background: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'heading_icon_color',
				[
					'label' => esc_html__( 'Border Icon Color', 'futexo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tpsub-title-two i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'heading_subtitle',
				[
					'label' => esc_html__( 'Heading Subtitle', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'separator' => 'before',
					'default' => esc_html__( 'Subtitle', 'futexo' ),
					'placeholder' => esc_html__( 'Subtitle', 'futexo' ),
				]
			);
			$this->add_control(
				'heading_subtitle_color',
				[
					'label' => esc_html__( 'Heading Subtitle Color', 'futexo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tpsub-title-two' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'heading_title',
				[
					'label' => esc_html__( 'Heading Title ', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'separator' => 'before',
					'default' => esc_html__( 'Heading', 'futexo' ),
					'placeholder' => esc_html__( 'Heading', 'futexo' ),
				]
			);
			$this->add_control(
				'heading_title_clr',
				[
					'label' => esc_html__( 'Heading Title Color', 'futexo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .section-title-two' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'heading_des',
				[
					'label' => esc_html__( 'Heading Description ', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'separator' => 'before',
					'default' => esc_html__( 'Duis nunc sodales conubia a laoreet aliquet on nostra eleifend lacinia prasent hendrerit quisque penatibus erat a pulvina integer semper ridiculus lectus con dimentum obor tise verodar capmtaso morin', 'futexo' ),
					'placeholder' => esc_html__( 'Duis nunc sodales conubia a laoreet aliquet on nostra eleifend lacinia prasent hendrerit quisque penatibus erat a pulvina integer semper ridiculus lectus con dimentum obor tise verodar capmtaso morin', 'futexo' ),
				]
			);
			$this->add_control(
				'heading_des_clr',
				[
					'label' => esc_html__( 'Heading Description Color', 'futexo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .section-description' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'head_style',
				[
					'label' => esc_html__( 'Heading Style', 'futexo' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '1',
					'separator' => 'before',
					'options' => [
						'1'  => esc_html__( 'style 1', 'futexo' ),
						'2' => esc_html__( 'style 2', 'futexo' ),
					],
				]
			);
			$this->end_controls_section();

			$this->start_controls_section(
				'heading_style',
				[
					'label' => esc_html__( 'Styles', 'futexo' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
			$this->add_control(
				'heading_subtitle_line',
				[
					'label' => esc_html__( 'Heading Subtitle', 'futexo' ),
					'type' => \Elementor\Controls_Manager::HEADING,
	
				]
			);
			$this->add_responsive_control(
				'heading_subtitle_font_size',
				[
					'label' => esc_html__( 'Size', 'elementor' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ '%', 'px','em' ],
					'range' => [
						'px' => [
							'min' => 6,
							'max' => 300,
						],
					],
					'default' => [
						'size' => 22,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .tpsub-title-two' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'heading_subtitle_font_height',
				[
					'label' => esc_html__( 'Line Height', 'elementor' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ '%', 'px','em' ],
					'range' => [
						'px' => [
							'min' => 6,
							'max' => 300,
						],
					],
					'default' => [
						'size' => 1.2,
						'unit' => 'em',
					],
					'selectors' => [
						'{{WRAPPER}} .tpsub-title-two' => 'line-height: {{SIZE}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);
			$this->add_control(
				'heading_title_line',
				[
					'label' => esc_html__( 'Heading title', 'futexo' ),
					'type' => \Elementor\Controls_Manager::HEADING,
	
				]
			);
			$this->add_responsive_control(
				'heading_title_font_size',
				[
					'label' => esc_html__( 'Size', 'elementor' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ '%', 'px','em' ],
					'range' => [
						'px' => [
							'min' => 6,
							'max' => 300,
						],
					],
					'default' => [
						'size' => 60,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .section-title-two' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'heading_title_font_height',
				[
					'label' => esc_html__( 'Line Height', 'elementor' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ '%', 'px','em' ],
					'range' => [
						'px' => [
							'min' => 6,
							'max' => 300,
						],
					],
					'default' => [
						'size' => 1,
						'unit' => 'em',
					],
					'selectors' => [
						'{{WRAPPER}} .section-title-two' => 'line-height: {{SIZE}}{{UNIT}};',
					],
					'separator' => 'after',
				]
			);


		
	}
	
		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$heading_subtitle = $settings['heading_subtitle'];
		$heading_icon = $settings['heading_icon']['value'];
		$heading_title = $settings['heading_title'];
		$heading_des = $settings['heading_des'];
		$head_style = $settings['head_style'];
		
		if($head_style == '1'){

		?>

<div class="section-wrap-two text-center wow fadeInUp" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
    <span class="tpsub-title-two mb-15"><i class="<?php echo $heading_icon; ?>"></i><?php echo $heading_subtitle; ?><i class="<?php echo $heading_icon; ?>"></i></span>
     <h3 class="section-title-two  mb-30"><?php echo $heading_title; ?></h3>
     </div>

	 <?php }else{?>

	 <div class="section-wrap">
                           <span class="tpsub-title mb-15"><?php echo $heading_subtitle; ?></span>
                           <h3 class="section-title mb-20"><?php echo $heading_title; ?></h3>
                           <span class="section-border mb-20"><i class="<?php echo $heading_icon; ?>"></i></span>
                           <p class="section-description mb-40"><?php echo $heading_des;?></p>
                        </div>

<?php
	}}

}
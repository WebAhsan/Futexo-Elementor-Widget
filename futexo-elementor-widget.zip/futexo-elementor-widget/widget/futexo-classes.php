<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_classes_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-classes';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Classes', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-table-of-contents';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_trainer',
			[
				'label' => esc_html__( 'Fitness Trainer', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'classes_style',
			[
				'label' => esc_html__( 'Classes Style', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-2',
				'options' => [
					'style-1'  => esc_html__( ' Style 1', 'futexo' ),
					'style-2'  => esc_html__( '	Style 2', 'futexo' ),
					'style-3'  => esc_html__( ' Style 3', 'futexo' ),

				],
			]
		);
		$this->add_control(
			'classes_show',
			[
				'label' => esc_html__( 'Classes Show', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '6',
				'options' => [
					'3'  => esc_html__( ' 3', 'futexo' ),
					'6'  => esc_html__( ' 6', 'futexo' ),
					'9'  => esc_html__( ' 9', 'futexo' ),
					'-1'  => esc_html__( ' -1', 'futexo' ),


				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Trainer Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);

		$this->add_control(
			'classes_title_color',
			[
				'label' => esc_html__( 'Title Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .class_title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'classes_title_typography',
				'selector' => '{{WRAPPER}} .class_title',
			]
		);
		$this->add_control(
			'class_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .class_icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'class_icon_bg',
			[
				'label' => esc_html__( 'Icon Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .class_icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'classes_icon_typography',
				'selector' => '{{WRAPPER}} .class_icon i',
				'separator' => 'after',
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);

		
		$this->add_control(
			'classes_title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .class_title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'classes_title_typography',
				'selector' => '{{WRAPPER}} .class_title',
			]
		);
		$this->add_control(
			'class_icon_color_hover',
			[
				'label' => esc_html__( 'Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .single-class:hover .class_icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'class_icon_bg_hover',
			[
				'label' => esc_html__( 'Icon Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				
				'selectors' => [
					'{{WRAPPER}} .single-class:hover .class_icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'classes_icon_typography_hover',
				'selector' => '{{WRAPPER}} .single-class:hover .class_icon i',
				'separator' => 'after',
			]
		);

		$this->end_controls_section();




	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$classes_style = $settings['classes_style'];
		$classes_show = $settings['classes_show'];

		if($classes_style == 'style-1'){
			$classes_styles = 'col-lg-3 col-md-4';
		}
		elseif($classes_style == 'style-2'){
			$classes_styles = 'col-lg-4 col-md-6';
		}
		elseif($classes_style == 'style-3'){
			$classes_styles = 'col-lg-6 col-md-12';
		} ?>

<div class="row mt-30">

<?php

		$args = array(

			'post_type' => 'our_classes',
			'posts_per_page' =>  $classes_show,
		);

		$fitness_classes_queery = new WP_Query($args);
		while($fitness_classes_queery->have_posts()):$fitness_classes_queery->the_post();
		$add_classes_icon = get_field('add_classes_icon');
		
		?>

 
					<div class="<?php echo $classes_styles; ?>">
                     <div class="single-class mb-40">
                        <div class="class-iamge">
                           <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" class="img-fluid" alt="class-img"></a>
                        </div>
                        <div class="class-info text-center">
                           <div class="class_icon mb-10">
                              <i class="<?php echo $add_classes_icon; ?>"></i>
                           </div>
                           <h4 class="class_title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
                           <div class="class_btn">
                              <a href="<?php the_permalink(); ?>">Read More<i class="fal fa-chevron-double-right"></i></a>
                           </div>
                        </div>
                     </div>
                  </div>

				<?php  endwhile;?>

	</div>

<?php

	
	}

}
<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_price_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-price-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Price Table', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_price_header',
			[
				'label' => esc_html__( 'Header', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'price_image',
			[
				'label' => esc_html__( 'Price Image', 'futexo' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_price',
			[
				'label' => esc_html__( 'Price', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->add_control(
			'price_text',
			[
				'label' => esc_html__( 'Price', 'futexo' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => '35',
			]
		);
		$this->add_control(
			'price_period',
			[
				'label' => esc_html__( 'period ', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'monthly',
				'options' => [
					'monthly'  => esc_html__( 'Monthly', 'futexo' ),
					'yearly'  => esc_html__( 'Yearly', 'futexo' ),
				],
			]
		);
		$this->add_control(
			'price_type',
			[
				'label' => esc_html__( 'Type ', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'standard',
				'options' => [
					'standard'  => esc_html__( 'Standard', 'futexo' ),
					'premium'  => esc_html__( 'Premium', 'futexo' ),
					'platinum'  => esc_html__( 'Platinum', 'futexo' ),
				],
			]
		);
		$this->add_control(
			'price_ribon',
			[
				'label' => esc_html__( 'Price Ribon', 'futexo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'futexo' ),
				'label_off' => esc_html__( 'Hide', 'futexo' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'ribon_text',
			[
				'label' => esc_html__( 'Ribon Text', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'POPULAR', 'futexo' ),
				'placeholder' => esc_html__( 'POPULAR', 'futexo' ),
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_price_feature',
			[
				'label' => esc_html__( 'Feature', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'fitness_price_feature_icon',
			[
				'label' => esc_html__( 'Feature Icon', 'futexo' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'label_block' => true,
				'default' => [
					'value' => 'fal fa-check',
					'library' => 'solid',
				],
			]
		);


		$repeater->add_control(
			'fitness_price_feature_text', 
			[
				'label' => esc_html__( 'Feature Text', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Personal Trainer' , 'futexo' ),
			]
		);

		$this->add_control(
			'fitness_price_feature_list',
			[
				'label' => esc_html__( 'Feature List', 'futexo' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'fitness_price_feature_icon' => esc_html__( 'fal fa-check', 'futexo' ),
						'fitness_price_feature_text' => esc_html__( 'Personal Trainer', 'futexo' ),
					],
				],
				'title_field' => '{{{ fitness_price_feature_text }}}',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_price_btn',
			[
				'label' => esc_html__( 'Button', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'fitness_price_btn_text', 
			[
				'label' => esc_html__( 'Button Text', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Join Today' , 'futexo' ),
			]
		);

		$this->add_control(
			'fitness_price_btn_url', 
			[
				'label' => esc_html__( 'Button Url', 'futexo' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://google.com', 'futexo' ),
				'default' => [
					'url' => '',
				],
			]
		);


		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_price_background',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__( 'Background', 'plugin-name' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .price_info ',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_price_style',
			[
				'label' => esc_html__( 'Price Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .price h5' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .price h5',
			]
		);
		$this->add_control(
			'period_color',
			[
				'label' => esc_html__( 'Period Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .price p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'period_typography',
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .price p',
			]
		);
		$this->add_control(
			'type_color',
			[
				'label' => esc_html__( 'Type Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .price_type' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'type_typography',
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .price_type',
			]
		);
		$this->add_control(
			'ribon_color',
			[
				'label' => esc_html__( 'Ribon Color', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .price__popular span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'ribon_bg',
			[
				'label' => esc_html__( 'Ribon Background', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .price__popular span' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'ribon_typography',
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .price__popular span',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_featuer_style',
			[
				'label' => esc_html__( 'Featuer Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'feature_icon_color',
			[
				'label' => esc_html__( 'Feature Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .tp_pricing-list ul li i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'feature_icon_typography',
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .tp_pricing-list ul li i',
			]
		);
		$this->add_control(
			'feature_text_color',
			[
				'label' => esc_html__( 'Feature Text Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .tp_pricing-list ul li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'feature_text_typography',
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .tp_pricing-list ul li',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'fitness_button_style',
			[
				'label' => esc_html__( 'Button Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);
		$this->add_control(
			'feature_btn_color',
			[
				'label' => esc_html__( ' Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
			
				'selectors' => [
					'{{WRAPPER}} .price-btn .tp-btn-round' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_btn_bg',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
			
				'selectors' => [
					'{{WRAPPER}} .price-btn .tp-btn-round' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'feature_btn_typography',
			
				'separator' => 'after',
				'selector' => '{{WRAPPER}} .price-btn .tp-btn-round',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'feature_btn_border',
	
				'label' => esc_html__( 'Border', 'plugin-name' ),
				'selector' => '{{WRAPPER}} .price-btn .tp-btn-round',
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);
		$this->add_control(
			'feature_btn_color_hover',
			[
				'label' => esc_html__( ' Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
	
				'selectors' => [
					'{{WRAPPER}} .price-btn .tp-btn-round:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'feature_btn_bg_hover',
			[
				'label' => esc_html__( 'Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
		
				'selectors' => [
					'{{WRAPPER}} .price-btn .tp-btn-round:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'feature_btn_typography_hover',

				'separator' => 'after',
				'selector' => '{{WRAPPER}} .price-btn .tp-btn-round:hover',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'feature_btn_border_hover',

				'label' => esc_html__( 'Border', 'plugin-name' ),
				'selector' => '{{WRAPPER}} .price-btn .tp-btn-round:hover',
			]
		);
	}



	protected function render() {
		$settings = $this->get_settings_for_display();	
		$price_image = $settings['price_image']['url'];
		$price_text = $settings['price_text'];
		$price_period = $settings['price_period'];
		$price_type = $settings['price_type'];
		$fitness_price_feature_lists = $settings['fitness_price_feature_list'];
		$fitness_price_btn_text = $settings['fitness_price_btn_text'];
		$fitness_price_btn_url = $settings['fitness_price_btn_url']['url'];
		$price_ribon = $settings['price_ribon'];
		$ribon_text = $settings['ribon_text'];
		
		
		
		?>


				<div class="price_item mb-30 wow fadeInUp" data-wow-delay=".6s">
                              <div class="priceing_image mb-10">
                                 <img src="<?php echo $price_image; ?>" alt="" class="img-fluid">

								 <?php if($price_ribon == 'yes'){?>
								 <div class="price__popular">
                                    <span><?php  echo $ribon_text;?></span>
                                 </div>
								 <?php } ?>
                              </div>
                              <div class="price_info pt-80" data-background="assets/img/priceing/price-bg.png">
                                 <div class="price text-center">
                                    <div class="inner">
                                       <h5>$<?php echo $price_text; ?></h5>
                                       <p><?php echo $price_period; ?></p>
                                    </div>
                                 </div>
                                 <h5 class="price_type mb-20 text-center"><?php echo $price_type;?></h5>
                                 <div class="tp_pricing-list pb-45">
                                    <ul>
										<?php foreach($fitness_price_feature_lists as $fitness_price_feature_list){?>
                                       <li><i class="<?php echo $fitness_price_feature_list['fitness_price_feature_icon']['value'];?>"></i><?php echo $fitness_price_feature_list['fitness_price_feature_text'];?> </li>
										<?php }?>
                                    </ul>
                                 </div>
                                 <div class="price-btn text-center pb-30">
                                    <a href="<?php echo $fitness_price_btn_url; ?>" class="tp-btn-round"><?php echo $fitness_price_btn_text; ?><i class="fal fa-chevron-double-right"></i></a>
                                 </div>
                              </div>
                           </div>

		
	<?php	
	}

}
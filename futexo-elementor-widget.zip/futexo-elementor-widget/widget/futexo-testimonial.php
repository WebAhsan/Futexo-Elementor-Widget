<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_testimonail_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-testimonail';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Testimonail', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'fitness_testimonial',
			[
				'label' => esc_html__( 'Fuutexo Testimonial', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'testimonial_des', [
				'label' => esc_html__( 'Testimonail', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'List Title' , 'futexo' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'client_name', [
				'label' => esc_html__( 'Client Name', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Calwen Synton' , 'futexo' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'client_degination', [
				'label' => esc_html__( 'Client Degination', 'futexo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Sr Designer' , 'futexo' ),
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'testimonial_img',
			[
				'label' => esc_html__( 'Add Image', 'futexo' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);


		$this->add_control(
			'tesitmonial',
			[
				'label' => esc_html__( 'Repeater List', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'testimonial_img' => esc_html__( 'Image', 'futexo' ),
						'testimonial_des' => esc_html__( 'Title #1', 'futexo' ),
						'client_name' => esc_html__( 'Calwen Synton', 'futexo' ),
						'client_degination' => esc_html__( 'Sr Designer', 'futexo' ),

					],
				],
				'title_field' => '{{{ client_name }}}',
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Trainer Style', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'icon_colors' );
		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => esc_html__( 'Normal', 'futexo' ),
			]
		);

		$this->add_control(
			'des_color',
			[
				'label' => esc_html__( 'Description Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial_description' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'name_color',
			[
				'label' => esc_html__( 'Name Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .client-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'degination_color',
			[
				'label' => esc_html__( 'Degination Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .client-degination' => 'color: {{VALUE}}',
				],
			]
		);

		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'futexo' ),
				'selector' => '{{WRAPPER}} .trainer-soicial-icon a',
			]
		);
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => esc_html__( 'Hover', 'futexo' ),
			]
		);
		$this->add_control(
			'icon_color_hover',
			[
				'label' => esc_html__( 'Icon Color', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'icon_bg_color_hover',
			[
				'label' => esc_html__( 'Icon Background', 'futexo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .trainer-soicial-icon a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border_hover',
				'label' => esc_html__( 'Border', 'futexo' ),
				'selector' => '{{WRAPPER}} .trainer-soicial-icon a:hover',
			]
		);

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		
		$tesitmonials =  $settings['tesitmonial'];
		?>


<script>
	jQuery(function(){
		if (jQuery(".testimonial_active").length > 0) {
		let testimonialTwo = new Swiper('.testimonial_active', {
			slidesPerView: 1,
			spaceBetween: 30,
			// direction: 'vertical',
			loop: true,
			autoplay: {
				delay: 6000,
			},

			// If we need pagination
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			// Navigation arrows
			navigation: {
				nextEl: '.ts-button-next',
				prevEl: '.ts-button-prev',
			},

			// And if we need scrollbar
			scrollbar: {
				el: '.swiper-scrollbar',
			},
			breakpoints: {
				550: {
					slidesPerView: 1,
				},
				768: {
					slidesPerView: 1,
				},
				1200: {
					slidesPerView: 1,
				},
				1400: {
					slidesPerView: 1,
				}
			}
		});
	}
	})
</script>

<div class="testimonial-area">
            <div class="container">
               <div class="pt-120 pb-115" >
                  <div class="row justify-content-center">
                     <div class="col-xxl-10 col-xl-11 col-lg-12">
                        <div class="swiper-container testimonial_active">
                           <div class="testimonial-wrapper swiper-wrapper wow fadeInUp" data-wow-delay=".4s">

							<?php foreach($tesitmonials as $tesitmonial){ ?>
                              <div class="testimonial-slider-item swiper-slide text-center">
                                 <div class="tesimonial-quote mb-60">
                                    <img src="<?php echo $tesitmonial['testimonial_img']['url'];  ?>" alt="">
                                 </div>
                                 <div class="testimonial-info">
                                    <p class="testimonial_description pb-50"><?php 

										echo $tesitmonial['testimonial_des'];
									
									
									?></p>
                                    <h5 class="client-name"><?php 
									echo $tesitmonial['client_name'];
									?></h5>
                                    <span class="client-degination"><?php 
										echo $tesitmonial['client_degination'];
										?></span>
                                 </div>
                              </div>
							  <?php } ?>
                           </div>
                           <!-- If we need navigation buttons -->
                           <div class="swiper-button-prev ts-button ts-button-prev"></div>
                           <div class="swiper-button-next ts-button ts-button-next"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

		 <?php
	}

}
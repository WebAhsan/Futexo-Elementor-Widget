<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_button_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-button';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Button', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-form-vertical';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'feature_button',
			[
				'label' => esc_html__( 'Futexo button', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
			);
			$this->add_control(
				'button_text',
				[
					'label' => esc_html__( 'Button Text', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'What do we do', 'futexo' ),
					'placeholder' => esc_html__( 'What do we do', 'futexo' ),
				]
			);
			$this->add_control(
				'button_url',
				[
					'label' => esc_html__( 'Button URL', 'futexo' ),
					'type' => \Elementor\Controls_Manager::URL,
					'separator' => 'after',
					'default' => [
						'url' => '#',
						'is_external' => false,
						'nofollow' => false,
						'custom_attributes' => '',
					],
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => esc_html__( 'Button Icon', 'futexo' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'separator' => 'before',
					'fa4compatibility' => 'icon',
					'default' => [
						'value' => 'fas fa-angle-double-right',
					],
				]
			);
			$this->add_control(
				'futexo_icon_align',
				[
					'label' => esc_html__( 'Icon Position', 'futexo' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'right',
					'options' => [
						'left' => esc_html__( 'Before', 'futexo' ),
						'right' => esc_html__( 'After', 'futexo' ),
					],
				]
			);
			$this->add_control(
				'button_bg',
				[
					'label' => esc_html__( 'Button Background', 'futexo' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'separator' => 'after',
					'selectors' => [
						'{{WRAPPER}} .tp-btn-round' => 'background: {{VALUE}}',
					],
				]
			);
			$this->end_controls_section();

			$this->start_controls_section(
				'feature_button_style',
				[
					'label' => esc_html__( 'Button Style', 'futexo' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
				);
				$this->start_controls_tabs( 'icon_colors' );
				$this->start_controls_tab(
					'icon_colors_normal',
					[
						'label' => esc_html__( 'Normal', 'futexo' ),
					]
				);
				$this->add_control(
					'button_text_color',
					[
						'label' => esc_html__( 'Button Text Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .tp-btn-round' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'button_icon_color',
					[
						'label' => esc_html__( 'Button Icon Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .tp-btn-round i' => 'color: {{VALUE}}',
						],
					]
				);
				
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'content_typography',
						'selector' => '{{WRAPPER}} .tp-btn-round',
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'border',
						'label' => esc_html__( 'Border', 'futexo' ),
						'selector' => '{{WRAPPER}} .tp-btn-round',
						'separator' => 'before',
					]
				);
				$this->end_controls_tab();
		
				$this->start_controls_tab(
					'icon_colors_hover',
					[
						'label' => esc_html__( 'Hover', 'futexo' ),
					]
				);
				$this->add_control(
					'button_bg_hover',
					[
						'label' => esc_html__( 'Button Background', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .tp-btn-round:hover' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'button_text_color_hover',
					[
						'label' => esc_html__( 'Button Text Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .tp-btn-round:hover' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'button_icon_color_hover',
					[
						'label' => esc_html__( 'Button Icon Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .tp-btn-round:hover i' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'content_typography',
						'selector' => '{{WRAPPER}} .tp-btn-round:hover',
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'border_btn',
						'label' => esc_html__( 'Border', 'futexo' ),
						'selector' => '{{WRAPPER}} .tp-btn-round:hover',
					]
				);
	}
	
		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$button_icon = $settings['button_icon']['value'];
		$button_text = $settings['button_text'];
		$futexo_icon_align = $settings['futexo_icon_align'];
		$button_url = $settings['button_url']['url'];
		
		?>

<a href="<?php echo $button_url; ?>" class="tp-btn-round">
	<?php if($futexo_icon_align == 'right'){?>
	<?php echo $button_text; ?> <i class="<?php echo $button_icon;?>"></i>
	<?php }else{?>
		<i class="<?php echo $button_icon;?>"></i><?php echo $button_text; ?> 
	<?php } ?>
</a>
<?php
	}

}
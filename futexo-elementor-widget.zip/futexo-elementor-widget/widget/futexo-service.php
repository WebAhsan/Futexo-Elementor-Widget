<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_service_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-service';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Services', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-chain-broken';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'feature_services',
			[
				'label' => esc_html__( 'Futexo Services Box', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
			);
			$this->add_control(
				'service_title',
				[
					'label' => esc_html__( 'Service Title', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'separator' => 'before',
					'label_block' => true,
					'default' => esc_html__( 'Weight Lifting', 'futexo' ),
					'placeholder' => esc_html__( 'Weight Lifting', 'futexo' ),
				]
			);
			$this->add_control(
				'service_des',
				[
					'label' => esc_html__( 'Service Description', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'separator' => 'after',
					'default' => esc_html__( 'Commodo metuse a dictum faucibus felis', 'futexo' ),
					'placeholder' => esc_html__( 'Commodo metuse a dictum faucibus felis', 'futexo' ),
				]
			);
			$this->add_control(
				'service_icon',
				[
					'label' => esc_html__( 'Service Icon', 'futexo' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'separator' => 'before',
					'fa4compatibility' => 'icon',
					'default' => [
						'value' => 'fab fa-500px',
					],
				]
			);
			$this->add_control(
				'service_url',
				[
					'label' => esc_html__( 'Service Icon URL', 'futexo' ),
					'type' => \Elementor\Controls_Manager::URL,
					'separator' => 'after',
					'placeholder' => esc_html__( '#', 'futexo' ),
					'default' => [
						'url' => '',
						'is_external' => false,
						'nofollow' => false,
						'custom_attributes' => '',
					],
				]
			);

			$this->add_control(
				'service_btn_text',
				[
					'label' => esc_html__( 'Button Text', 'futexo' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'separator' => 'before',
					'label_block' => true,
					'default' => esc_html__( 'Read More', 'futexo' ),
					'placeholder' => esc_html__( 'Read More', 'futexo' ),
				]
			);
			$this->add_control(
				'service_button_url',
				[
					'label' => esc_html__( 'Button URL', 'futexo' ),
					'type' => \Elementor\Controls_Manager::URL,
					'separator' => 'after',
					'label_block' => true,
					'default' => [
						'url' => '#',
						'is_external' => false,
						'nofollow' => false,
						'custom_attributes' => '',
					],
				]
			);
			$this->end_controls_section();


			$this->start_controls_section(
				'feature_serivce_style',
				[
					'label' => esc_html__( 'Services Style', 'futexo' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
				);
				$this->start_controls_tabs( 'icon_colors' );
				$this->start_controls_tab(
					'icon_colors_normal',
					[
						'label' => esc_html__( 'Normal', 'futexo' ),
					]
				);
				$this->add_control(
					'service_box_bg',
					[
						'label' => esc_html__( 'Service Background', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'after',
						'selectors' => [
							'{{WRAPPER}} .services-item' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'service_icon_bg',
					[
						'label' => esc_html__( 'Icon Background', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .services-icon' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'service_icon_typography',
						'selector' => '{{WRAPPER}} .services-icon i',
						'separator' => 'after',
					]
				);
				$this->add_control(
					'service_title_clr',
					[
						'label' => esc_html__( 'Service Title Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .services-item-title' => 'color: {{VALUE}}',
						],
					]
				);
				
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'service_title_typography',
						'selector' => '{{WRAPPER}} .services-item-title',
						'separator' => 'after',
					]
				);
				$this->add_control(
					'service_des_clr',
					[
						'label' => esc_html__( 'Service Description Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .services-item p' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'service_des_typography',
						'selector' => '{{WRAPPER}} .services-item p',
						'separator' => 'after',
					]
				);
				$this->end_controls_tab();
		
				$this->start_controls_tab(
					'icon_colors_hover',
					[
						'label' => esc_html__( 'Hover', 'futexo' ),
					]
				);
				$this->add_control(
					'service_box_bg_hover',
					[
						'label' => esc_html__( 'Service Background', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'after',
						'selectors' => [
							'{{WRAPPER}} .services-item:hover' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'service_icon_bg_hover',
					[
						'label' => esc_html__( 'Icon Background', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .services-item:hover .services-icon' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'service_icon_hover_typography',
						'selector' => '{{WRAPPER}} .services-item:hover .services-icon i',
						'separator' => 'after',
					]
				);
				$this->add_control(
					'service_title_clr_hover',
					[
						'label' => esc_html__( 'Service Title Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .services-item:hover .services-item-title' => 'color: {{VALUE}}',
						],
					]
				);
				
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'service_title_hover_typography',
						'selector' => '{{WRAPPER}} .services-item-title',
						'separator' => 'after',
					]
				);
				$this->add_control(
					'service_des_clr_hover',
					[
						'label' => esc_html__( 'Service Description Color', 'futexo' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'separator' => 'before',
						'selectors' => [
							'{{WRAPPER}} .services-item:hover.services-item p' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'service_des_hover_typography',
						'selector' => '{{WRAPPER}} .services-item p',
						'separator' => 'after',
					]
				);
				
	}
	
		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$service_text = $settings['service_title'];
		$service_des = $settings['service_des'];
		$service_icon = $settings['service_icon']['value'];
		$service_url = $settings['service_url']['url'];
		$service_btn_text = $settings['service_btn_text'];
		$service_button_url = $settings['service_button_url'];
		?>


		<div class="services-item text-center wow fadeInUp mb-30" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
		<div class="sv-inner sv-inner2">
			<div class="services-icon">
				<i class="<?php echo $service_icon;?>"></i>
			</div>
		</div>
		<h4 class="services-item-title services-item-title-2 mb-20"><a href="<?php echo $service_url;?>"><?php echo $service_text;?></a></h4>
		<p class="mb-25"><?php echo $service_des;?></p>
			<a href="<?php echo $service_button_url;?>" class="services-item-btn"><?php echo $service_btn_text;?> <i class="fal fa-chevron-double-right"></i></a>
		</div>s
<?php
	}

}
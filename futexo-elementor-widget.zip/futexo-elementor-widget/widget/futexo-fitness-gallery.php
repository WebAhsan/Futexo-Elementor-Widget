<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class futexo_fitness_gallery_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Futexo widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'futex-gallery';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Futexo Gallery', 'futexo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'futexo', 'url', 'link' ];
	}

	
	/**
	 * Register oEmbed widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'fitness_gallery',
			[
				'label' => esc_html__( 'Futexo Gallery', 'futexo' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
			);


			$this->add_control(
				'gallery_show',
				[
					'label' => esc_html__( 'Show Gallery', 'futexo' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => '3',
			
					
					'options' => [
						'1'  => esc_html__( '1', 'futexo' ),
						'2'  => esc_html__( '2', 'futexo' ),
						'3'  => esc_html__( '3', 'futexo' ),
						'4'  => esc_html__( '4', 'futexo' ),
						'5'  => esc_html__( '5', 'futexo' ),
						'6'  => esc_html__( '6', 'futexo' ),
					],
				]
			);
			$this->add_control(
				'gallery_slider_autoplay',
				[
					'label' => esc_html__( 'Gallery Autoplay', 'futexo' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Yes', 'futexo' ),
					
					'label_off' => esc_html__( 'No', 'futexo' ),
					'return_value' => 'true',
					'default' => 'true',
					
				]
			);

			$this->add_control(
				'gallery_autoplay_speed',
				[
					'label' => esc_html__( 'Autoplay Speed', 'futexo' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
				
					'default' => 5000,
					
				]
			);
			$this->add_control(
				'gallery_slider_dots',
				[
					'label' => esc_html__( 'Gallery Dots', 'futexo' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Yes', 'futexo' ),
				
					'label_off' => esc_html__( 'No', 'futexo' ),
					'return_value' => 'true',
					'default' => 'false',
				
				]
			);
			

			$this->end_controls_section();

			$this->start_controls_section(
				'feature_button_style',
				[
					'label' => esc_html__( 'Button Style', 'futexo' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
				);
				$this->start_controls_tabs( 'icon_colors' );
				$this->start_controls_tab(
					'icon_colors_normal',
					[
						'label' => esc_html__( 'Normal', 'futexo' ),
					]
				);

				$this->end_controls_tab();
		
				$this->start_controls_tab(
					'icon_colors_hover',
					[
						'label' => esc_html__( 'Hover', 'futexo' ),
					]
				);
	}
	


		/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<script>
		jQuery(function(){
			jQuery('.fitness-slider_active').owlCarousel({
		loop: true,
		center: true,
		margin: 0,
		autoplay: '<?php echo $settings['gallery_slider_autoplay'] ?>',
		autoplayTimeout: '<?php echo $settings['gallery_autoplay_speed'] ?>',
		smartSpeed: 500,
		items: '<?php echo $settings['gallery_show'] ?>',
		navText: ['<button><i class="fal fa-angle-left"></i></button>', '<button><i class="fal fa-angle-right"></i></button>'],
		nav: false,
		dots: '<?php echo $settings['gallery_slider_dots'] ?>',

	});


		});

	</script>
<div class="gallery-items fix">
               <div class="container-fluid">
                  <div class="row mt-55 gx-0">
                     <div class="col-xxl-12 gx-0">
                        <div class="fitness-slider_active owl-carousel">
						<?php

						$args = array(
							'post_type'      => 'fitness_port',
							
						);
						$loop = new WP_Query($args);
						while ( $loop->have_posts() ) {
							$loop->the_post();
						
						?>
                           <div class="fitness-item position-relative  wow flipInY" data-wow-delay=".3s"> 
                              <a href="<?php the_permalink();?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid"></a>
                              <div class="fitness-info">
                                 <div class="fitness-content">
                                    <span><a href="<?php the_permalink();?>"><?php  the_title(); ?></a></span>
                                    <p><?php echo substr(get_the_excerpt(), 0,30);?></p>
                                 </div>
                                 <div class="fitness-icon">
                                    <a href="<?php the_permalink();?>" class="tp-btn-circle"><i class="fal fa-chevron-double-right"></i></a>
                                 </div>
                              </div>
                           </div>

						   <?php } ?>

                        </div>
                     </div>
                  </div>
               </div>
            </div>




<?php
	}

}